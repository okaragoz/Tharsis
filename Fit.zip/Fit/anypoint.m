function [C_array] = anypoint(lon,lat) %Lon,lat2Cart

lambda = lon;
phi = lat;


x = cosd(phi).*cosd(lambda);
y = cosd(phi).*sind(lambda);
z = sind(phi);

C_array = [x, y, z]';
end

