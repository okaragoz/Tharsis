

function [Nvec_1] = Nvec_1(lonlat,Dcord) % ask for lonlat, const Dcord
Cvec = repmat([cosd(lonlat(2))*cosd(lonlat(1)),cosd(lonlat(2))*sind(lonlat(1)), sind(lonlat(2))],length(Dcord),1)'; % blow up C vector2size of Dcord
Nvec = cross(Cvec,Dcord);   % Cross product of Cvec x Dvec
Nvec_1 = Nvec ./ vecnorm(Nvec); % Divide to norm of Nvec
end