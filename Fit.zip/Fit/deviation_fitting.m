% Clear workspace, command window, and close all figures
clear; clc; close all;

% Import wrinkle ridge segment data
base = xlsread('./data/ALL.xls');

% Segment defined by two points A and B
Acord = anypoint(base(:, 8), base(:, 9));  % Coordinates of A point
Bcord = anypoint(base(:, 10), base(:, 11));  % Coordinates of B point

% Compute mid point of segments
Dcord = (Acord + Bcord) ./ 2;

% Normal vector for segments
Nvec_2 = cross(Acord, Bcord);
Nvec_2 = Nvec_2 ./ vecnorm(Nvec_2);

% Initial conditions
p_norm = 2;          % Fit constant
cent = 6;            % Number of centers
iter_cent = 200*cent; % Random center for start 

% Placeholder for center points
random_Center_points = zeros(3, cent);

% Loop over random centers
for j = 1:iter_cent
    % Generate random centers on globe
    for i = 1:cent
        random_Center_points(:, i) = randn(3, 1);
        random_Center_points(:, i) = random_Center_points(:, i) ./ vecnorm(random_Center_points(:, i));
        [LonLat(i, 1), LonLat(i, 2)] = cart2sph(random_Center_points(1, i), random_Center_points(2, i), random_Center_points(3, i));
    end
    LonLat = rad2deg(LonLat);

    % Compute deviation for each center
    for i = 1:cent
        Deviation(i, :) = abs(dot(Nvec_1(LonLat(i, :), Dcord), Nvec_2));
    end

    % Iterative fit of centers
    for k = 1:100
        [dev, Index] = min(Deviation);

        for i = 1:cent
            % Split data set for centers
            Dcord_red = Dcord(:, Index == i);
            Nvec_2red = Nvec_2(:, Index == i);
            
            % Define the function for reduced data
            funC_1red = @(lonlat) abs(dot(Nvec_1(lonlat, Dcord_red), Nvec_2red));
            funCred = @(lonlat) norm(funC_1red(lonlat), p_norm);
            
            % Calculate lonlat for separated sets (1 & 2)
            lonlat = fminsearch(funCred, LonLat(i, :));
            
            % Define function for all segments
            fc_centers = @(lonlat) abs(dot(Nvec_1(lonlat, Dcord), Nvec_2));
            Deviation(i, :) = fc_centers(lonlat);  % Compute deviation
            
            [dev, Index] = min(Deviation);
            LonLat(i, :) = lonlat;
        end
        
        % Save some of the results
        Fit_Index_M(:, k) = Index';
        Fit_Deviation_M(:, k) = dev';
    end
    
    % Save deviation and centers for all iterations
    Save_Deviation(j, :) = norm(Fit_Deviation_M(:, end), p_norm);
    Centers_LonLat_Calc(:, j) = LonLat(:);
    Index_Final(:, j) = Index';
end

% Find index of lowest deviation
[~, SS] = min(Save_Deviation);
Best_Index = Index_Final(:, SS);

% Save corresponding centers with lowest deviation
Best_Centers = reshape(Centers_LonLat_Calc(:, SS), [2, cent])';